
"use client";

import { useState } from "react";
import type { AuditFilters, AuditRecord } from "@/modules/m3/audit/auditTypes";

import AuditFiltersPanel from "@/modules/m3/components/AuditFilters";
import AuditStats from "@/modules/m3/components/AuditStats";
import AuditTable from "@/modules/m3/components/AuditTable";
import CheckInForm from "@/modules/m3/components/CheckInForm";
import { mockAuditLogs } from "@/modules/m3/audit/mockAuditData";

export default function AuditPage() {
    const [filters, setFilters] = useState<AuditFilters>({});
    const [logs] = useState<AuditRecord[]>(mockAuditLogs);

    const filteredLogs = logs.filter((log) => {
        if (filters.eventId && log.eventId !== filters.eventId) {
            return false;
        }

        if (filters.action && log.action !== filters.action) {
            return false;
        }

        if (
            filters.fromDate &&
            new Date(log.createdAt) < new Date(filters.fromDate)
        ) {
            return false;
        }

        if (
            filters.toDate &&
            new Date(log.createdAt) > new Date(filters.toDate)
        ) {
            return false;
        }

        return true;
    });

    return (
        <main className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <div className="mx-auto max-w-7xl space-y-6">
                {/* Header */}
                <header>
                    <p className="text-sm font-medium text-blue-600">
                        SeatLock / M3 Operations
                    </p>

                    <h1 className="mt-1 text-3xl font-bold text-gray-900">
                        Audit Dashboard
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Monitor system activity, bookings, check-ins and security events.
                    </p>
                </header>

                {/* Statistics */}
                <AuditStats logs={filteredLogs} />

                {/* Filters */}
                <AuditFiltersPanel
                    filters={filters}
                    onChange={setFilters}
                />
                <CheckInForm />
                {/* Audit Logs Table */}
                <AuditTable logs={filteredLogs} />

                <p className="text-center text-sm text-gray-400">
                    Audit dashboard · SeatLock Hackathon
                </p>
            </div>
        </main>
    );
}
