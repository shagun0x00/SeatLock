import {
    findEventsForAllShards,
    getActorShardResult,
} from "@/modules/m3/audit/shardTest";

export default function ShardTestPage() {
    const results = findEventsForAllShards();
    const actorShard = getActorShardResult();

    const shardCount = Object.keys(results).length;
    const passed = shardCount === 4;

    return (
        <main className="min-h-screen bg-gray-100 p-6 text-gray-900">
            <div className="mx-auto max-w-4xl space-y-6">

                <header className="rounded-xl bg-white p-6 shadow">
                    <h1 className="text-3xl font-bold">
                        Audit Shard Routing Test
                    </h1>
                    <p className="mt-2 text-gray-600">
                        Verify routing across four audit shards.
                    </p>
                </header>

                {/* Test Status */}
                <section className="rounded-xl bg-white p-6 shadow">
                    <h2 className="text-xl font-bold">Test Status</h2>

                    <p className={`mt-3 font-bold ${passed ? "text-green-700" : "text-red-700"}`}>
                        {passed ? "PASS - All 4 shards found" : "FAIL - Shards missing"}
                    </p>

                    <p className="mt-2 text-gray-700">
                        Shards found: {shardCount}/4
                    </p>
                </section>

                {/* Event Routing */}
                <section className="rounded-xl bg-white p-6 shadow">
                    <h2 className="mb-4 text-xl font-bold">Event Routing</h2>

                    <div className="space-y-3">
                        {Object.entries(results).map(([shard, eventId]) => (
                            <div
                                key={shard}
                                className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-gray-200 p-4"
                            >
                                <span className="font-medium text-gray-900">
                                    {eventId}
                                </span>

                                <span className="rounded-lg bg-blue-100 px-3 py-2 font-mono font-semibold text-blue-800">
                                    {shard}
                                </span>
                            </div>
                        ))}
                    </div>
                </section>

                {/* Actor Routing */}
                <section className="rounded-xl bg-white p-6 shadow">
                    <h2 className="text-xl font-bold">Actor Routing</h2>

                    <p className="mt-3 text-gray-700">
                        Actor ID: user-101
                    </p>

                    <p className="mt-2 font-mono font-bold text-blue-700">
                        Shard: {actorShard}
                    </p>
                </section>

                {/* All Shards */}
                <section className="rounded-xl bg-white p-6 shadow">
                    <h2 className="mb-4 text-xl font-bold">Available Shards</h2>

                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                        {[0, 1, 2, 3].map((number) => (
                            <div
                                key={number}
                                className="rounded-lg border bg-gray-50 p-4 text-center"
                            >
                                <p className="text-gray-600">Shard {number}</p>
                                <p className="mt-1 font-mono font-bold text-gray-900">
                                    audit_logs_{number}
                                </p>
                            </div>
                        ))}
                    </div>
                </section>

            </div>
        </main>
    );
}

// import {
//   getShardTestResults,
//   getActorShardResult,
// } from "@/modules/m3/audit/shardTest";

// export default function ShardTestPage() {
//   const results = getShardTestResults();
//   const actorShard = getActorShardResult();

//   return (
//     <main className="min-h-screen bg-gray-100 px-4 py-8 text-gray-900 sm:px-8">
//       <div className="mx-auto max-w-4xl space-y-6">

//         {/* Header */}
//         <header className="rounded-2xl bg-white p-6 shadow-sm">
//           <p className="text-sm font-semibold text-blue-700">
//             SeatLock / M3 Operations
//           </p>

//           <h1 className="mt-2 text-3xl font-bold text-gray-900">
//             Audit Shard Routing Test
//           </h1>

//           <p className="mt-2 text-gray-600">
//             Verify event-based and actor-based audit routing across 4 shards.
//           </p>
//         </header>

//         {/* Event Routing */}
//         <section className="overflow-hidden rounded-2xl border border-gray-300 bg-white shadow-sm">
//           <div className="border-b border-gray-200 p-5">
//             <h2 className="text-xl font-bold text-gray-900">
//               Event Routing
//             </h2>
//             <p className="mt-1 text-sm text-gray-600">
//               Event IDs are mapped to audit shard tables.
//             </p>
//           </div>

//           <div className="overflow-x-auto">
//             <table className="w-full text-left">
//               <thead className="bg-gray-100">
//                 <tr>
//                   <th className="px-5 py-4 text-sm font-semibold text-gray-800">
//                     Event ID
//                   </th>
//                   <th className="px-5 py-4 text-sm font-semibold text-gray-800">
//                     Shard Table
//                   </th>
//                 </tr>
//               </thead>

//               <tbody>
//                 {results.map((item) => (
//                   <tr
//                     key={item.eventId}
//                     className="border-t border-gray-200 hover:bg-gray-50"
//                   >
//                     <td className="px-5 py-4 font-medium text-gray-900">
//                       {item.eventId}
//                     </td>

//                     <td className="px-5 py-4">
//                       <span className="inline-flex rounded-lg bg-blue-100 px-3 py-1.5 font-mono text-sm font-semibold text-blue-800">
//                         {item.shard}
//                       </span>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </section>

//         {/* Actor Routing */}
//         <section className="rounded-2xl border border-gray-300 bg-white p-6 shadow-sm">
//           <h2 className="text-xl font-bold text-gray-900">
//             Actor Routing
//           </h2>

//           <p className="mt-2 text-gray-600">
//             Used when an audit action does not have an Event ID.
//           </p>

//           <div className="mt-5 grid gap-4 sm:grid-cols-2">
//             <div className="rounded-xl bg-gray-100 p-4">
//               <p className="text-sm font-medium text-gray-600">
//                 Actor ID
//               </p>
//               <p className="mt-1 font-semibold text-gray-900">
//                 user-101
//               </p>
//             </div>

//             <div className="rounded-xl bg-blue-50 p-4">
//               <p className="text-sm font-medium text-blue-700">
//                 Assigned Shard
//               </p>
//               <p className="mt-1 font-mono text-lg font-bold text-blue-900">
//                 {actorShard}
//               </p>
//             </div>
//           </div>
//         </section>

//         {/* Shard Information */}
//         <section className="rounded-2xl border border-gray-300 bg-white p-6 shadow-sm">
//           <h2 className="text-xl font-bold text-gray-900">
//             Shard Information
//           </h2>

//           <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
//             {[0, 1, 2, 3].map((shard) => (
//               <div
//                 key={shard}
//                 className="rounded-xl border border-gray-200 bg-gray-50 p-4 text-center"
//               >
//                 <p className="text-sm text-gray-600">Shard {shard}</p>
//                 <p className="mt-1 font-mono font-bold text-gray-900">
//                   audit_logs_{shard}
//                 </p>
//               </div>
//             ))}
//           </div>
//         </section>

//         <footer className="py-2 text-center text-sm text-gray-500">
//           SeatLock Hackathon · M3 Audit & Operations
//         </footer>
//       </div>
//     </main>
//   );
// }
