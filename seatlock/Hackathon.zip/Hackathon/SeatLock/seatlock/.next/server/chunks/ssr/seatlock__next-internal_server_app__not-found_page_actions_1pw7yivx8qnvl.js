module.exports=[61167,(a,b,c)=>{}];

//# sourceMappingURL=seatlock__next-internal_server_app__not-found_page_actions_1pw7yivx8qnvl.js.map