module.exports=[89420,(a,b,c)=>{}];

//# sourceMappingURL=seatlock__next-internal_server_app_shard-test_page_actions_09-54gamq6xlf.js.map