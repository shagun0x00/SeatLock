module.exports=[681,(a,b,c)=>{}];

//# sourceMappingURL=seatlock__next-internal_server_app_page_actions_1bhvkj87fohza.js.map