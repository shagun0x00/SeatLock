module.exports=[55384,(e,o,d)=>{}];

//# sourceMappingURL=seatlock__next-internal_server_app_favicon_ico_route_actions_0pl0gptdjd42z.js.map