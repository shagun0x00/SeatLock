module.exports=[8039,(a,b,c)=>{}];

//# sourceMappingURL=seatlock__next-internal_server_app__global-error_page_actions_1tjhy1y_jw-ji.js.map