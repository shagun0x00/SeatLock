globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/uOVF0mIHu23v8dBAnLHbq/_buildManifest.js",
    "static/uOVF0mIHu23v8dBAnLHbq/_ssgManifest.js",
    "static/uOVF0mIHu23v8dBAnLHbq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/380efazvu8v3y.js",
    "static/chunks/2t0_j55aeubs3.js",
    "static/chunks/2ux46xe28b9fu.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/380efazvu8v3y.js",
        "static/chunks/2t0_j55aeubs3.js",
        "static/chunks/2ux46xe28b9fu.js"
      ],
      "runtimeModuleIds": [
        39410
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/380efazvu8v3y.js",
        "static/chunks/2t0_j55aeubs3.js",
        "static/chunks/2ux46xe28b9fu.js"
      ],
      "runtimeModuleIds": [
        39410
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/380efazvu8v3y.js",
        "static/chunks/2t0_j55aeubs3.js",
        "static/chunks/2ux46xe28b9fu.js"
      ],
      "runtimeModuleIds": [
        39410
      ]
    },
    "/audit/page": {
      "otherChunks": [
        "static/chunks/380efazvu8v3y.js",
        "static/chunks/2t0_j55aeubs3.js",
        "static/chunks/2ux46xe28b9fu.js"
      ],
      "runtimeModuleIds": [
        39410
      ]
    },
    "/shard-test/page": {
      "otherChunks": [
        "static/chunks/380efazvu8v3y.js",
        "static/chunks/2t0_j55aeubs3.js",
        "static/chunks/2ux46xe28b9fu.js"
      ],
      "runtimeModuleIds": [
        39410
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
