var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]__0zk1g5u5ljb1v._.js")
R.c("server/chunks/[root-of-the-server]__1d1473uj2ct0k._.js")
R.c("server/chunks/seatlock__next-internal_server_app_favicon_ico_route_actions_0pl0gptdjd42z.js")
R.m(1705)
module.exports=R.m(1705).exports
