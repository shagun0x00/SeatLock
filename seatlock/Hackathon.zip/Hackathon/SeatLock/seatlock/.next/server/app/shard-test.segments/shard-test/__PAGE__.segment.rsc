1:"$Sreact.fragment"
2:"/_next/static/chunks/1yhdjxv1it622.js"
3:I[62670,["$2"],"default"]
4:I[11273,["$2"],"default"]
13:"ViewportBoundary"
14:I[85108,["$2"],"$13"]
15:"MetadataBoundary"
16:I[85108,["$2"],"$15"]
17:"$Sreact.suspense"
18:I[59355,["$2"],"IconMark"]
:HL["/_next/static/chunks/18pj6ihwu0rvj.css","style"]
6:X
6:C
7:X
7:300
7:C
a:X
a:C
12:X
12:C
b:[["children",{"s":"__PAGE__","h":49314,"d":{"r":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gray-100 p-6 text-gray-900","children":["$","div",null,{"className":"mx-auto max-w-4xl space-y-6","children":[["$","header",null,{"className":"rounded-xl bg-white p-6 shadow","children":[["$","h1",null,{"className":"text-3xl font-bold","children":"Audit Shard Routing Test"}],["$","p",null,{"className":"mt-2 text-gray-600","children":"Verify routing across four audit shards."}]]}],["$","section",null,{"className":"rounded-xl bg-white p-6 shadow","children":[["$","h2",null,{"className":"text-xl font-bold","children":"Test Status"}],["$","p",null,{"className":"mt-3 font-bold text-green-700","children":"PASS - All 4 shards found"}],["$","p",null,{"className":"mt-2 text-gray-700","children":["Shards found: ",4,"/4"]}]]}],["$","section",null,{"className":"rounded-xl bg-white p-6 shadow","children":[["$","h2",null,{"className":"mb-4 text-xl font-bold","children":"Event Routing"}],["$","div",null,{"className":"space-y-3","children":[["$","div","audit_logs_1",{"className":"flex flex-wrap items-center justify-between gap-3 rounded-lg border border-gray-200 p-4","children":[["$","span",null,{"className":"font-medium text-gray-900","children":"test-event-1"}],["$","span",null,{"className":"rounded-lg bg-blue-100 px-3 py-2 font-mono font-semibold text-blue-800","children":"audit_logs_1"}]]}],["$","div","audit_logs_2",{"className":"flex flex-wrap items-center justify-between gap-3 rounded-lg border border-gray-200 p-4","children":[["$","span",null,{"className":"font-medium text-gray-900","children":"test-event-2"}],["$","span",null,{"className":"rounded-lg bg-blue-100 px-3 py-2 font-mono font-semibold text-blue-800","children":"audit_logs_2"}]]}],["$","div","audit_logs_3",{"className":"flex flex-wrap items-center justify-between gap-3 rounded-lg border border-gray-200 p-4","children":[["$","span",null,{"className":"font-medium text-gray-900","children":"test-event-6"}],["$","span",null,{"className":"rounded-lg bg-blue-100 px-3 py-2 font-mono font-semibold text-blue-800","children":"audit_logs_3"}]]}],["$","div","audit_logs_0",{"className":"flex flex-wrap items-center justify-between gap-3 rounded-lg border border-gray-200 p-4","children":[["$","span",null,{"className":"font-medium text-gray-900","children":"test-event-8"}],["$","span",null,{"className":"rounded-lg bg-blue-100 px-3 py-2 font-mono font-semibold text-blue-800","children":"audit_logs_0"}]]}]]}]]}],["$","section",null,{"className":"rounded-xl bg-white p-6 shadow","children":["$Lc","$Ld","$Le"]}],"$Lf"]}]}],null,"$L10"]}],"p":"$@11","v":"$12","s":"$7"}}]]
8:[["children",{"s":"shard-test","h":49250,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@9","v":"$a","s":"$7"},"c":"$Qb"}]]
1a:X
1a:C
1d:X
1d:C
0:{"t":{"t":{"s":"","h":49234,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/18pj6ihwu0rvj.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/1yhdjxv1it622.js","async":true}]],["$","html",null,{"lang":"en","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]}]]}],"p":"$@5","v":"$6","s":"$7"},"c":"$Q8"},"h":{"r":["$","$1","h",{"children":[null,["$","$L14",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L16",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$17",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Create Next App"}],["$","meta","1",{"name":"description","content":"Generated by create next app"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L18","3",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@19","v":"$1a","s":"$7"}},"a":"$@1b","u":"$@1c","b":"uOVF0mIHu23v8dBAnLHbq","r":"$1d"}
1e:I[85108,["$2"],"OutletBoundary"]
c:["$","h2",null,{"className":"text-xl font-bold","children":"Actor Routing"}]
d:["$","p",null,{"className":"mt-3 text-gray-700","children":"Actor ID: user-101"}]
e:["$","p",null,{"className":"mt-2 font-mono font-bold text-blue-700","children":["Shard: ","audit_logs_2"]}]
f:["$","section",null,{"className":"rounded-xl bg-white p-6 shadow","children":[["$","h2",null,{"className":"mb-4 text-xl font-bold","children":"Available Shards"}],["$","div",null,{"className":"grid grid-cols-2 gap-3 sm:grid-cols-4","children":[["$","div","0",{"className":"rounded-lg border bg-gray-50 p-4 text-center","children":[["$","p",null,{"className":"text-gray-600","children":["Shard ",0]}],["$","p",null,{"className":"mt-1 font-mono font-bold text-gray-900","children":["audit_logs_",0]}]]}],["$","div","1",{"className":"rounded-lg border bg-gray-50 p-4 text-center","children":[["$","p",null,{"className":"text-gray-600","children":["Shard ",1]}],["$","p",null,{"className":"mt-1 font-mono font-bold text-gray-900","children":["audit_logs_",1]}]]}],["$","div","2",{"className":"rounded-lg border bg-gray-50 p-4 text-center","children":[["$","p",null,{"className":"text-gray-600","children":["Shard ",2]}],["$","p",null,{"className":"mt-1 font-mono font-bold text-gray-900","children":["audit_logs_",2]}]]}],["$","div","3",{"className":"rounded-lg border bg-gray-50 p-4 text-center","children":[["$","p",null,{"className":"text-gray-600","children":["Shard ",3]}],["$","p",null,{"className":"mt-1 font-mono font-bold text-gray-900","children":["audit_logs_",3]}]]}]]}]]}]
10:["$","$L1e",null,{"children":["$","$17",null,{"name":"Next.MetadataOutlet","children":"$@1f"}]}]
1c:false
1f:null
1b:null
9:"$undefined"
5:"$undefined"
19:"$undefined"
11:"$undefined"
