(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1y-fqgqeglqji._.css","static/chunks/1dte_next_dist_0k1k7-ncalmo1._.js"],
    source: "entry"
});
