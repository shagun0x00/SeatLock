(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/1dte_next_dist_compiled_204fue_26wllp._.js","static/chunks/1dte_next_dist_shared_lib_13ozsjivs0vwy._.js","static/chunks/1dte_next_dist_client_0r_untu5jhifb._.js","static/chunks/1dte_next_dist_0a2c6a4pmh25j._.js","static/chunks/[next]_entry_page-loader_ts_0us8f40_t-gfo._.js","static/chunks/1dte_react-dom_cjs_react-dom-client_development_02rz9zcargxd8.js","static/chunks/1dte_react-dom_cjs_react-dom_development_00h-fwcj3w1ch.js","static/chunks/1dte_react-dom_1cwiudm097nqd._.js","static/chunks/1dte_0sbyeriiuulq8._.js","static/chunks/[root-of-the-server]__118i5m1ij_l4j._.js"],
    source: "entry"
});
