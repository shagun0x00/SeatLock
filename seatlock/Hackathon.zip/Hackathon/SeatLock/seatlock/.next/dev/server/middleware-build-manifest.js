globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/1dte_next_dist_compiled_08y-or97m2rrk._.js",
      "static/chunks/1dte_next_dist_shared_lib_0e3pqfwbbq90-._.js",
      "static/chunks/1dte_next_dist_client_0vgpi737266ye._.js",
      "static/chunks/1dte_next_dist_1j8_2pyfuksl7._.js",
      "static/chunks/1dte_next_app_1qsqnjmkhpde1.js",
      "static/chunks/[next]_entry_page-loader_ts_0bj1w9hf2_86y._.js",
      "static/chunks/1dte_react-dom_cjs_react-dom-client_development_02rz9zcargxd8.js",
      "static/chunks/1dte_react-dom_cjs_react-dom_development_00h-fwcj3w1ch.js",
      "static/chunks/1dte_react-dom_1cwiudm097nqd._.js",
      "static/chunks/1dte_1qd45krqvo_d3._.js",
      "static/chunks/[root-of-the-server]__0ie6lbrg0o1km._.js",
      "static/chunks/seatlock_pages__app_0du2_q-cjzmdk._.js",
      "static/chunks/turbopack-seatlock_pages__app_15azr3v5pxd7p._.js"
    ],
    "/_error": [
      "static/chunks/1dte_next_dist_compiled_204fue_26wllp._.js",
      "static/chunks/1dte_next_dist_shared_lib_13ozsjivs0vwy._.js",
      "static/chunks/1dte_next_dist_client_0r_untu5jhifb._.js",
      "static/chunks/1dte_next_dist_0a2c6a4pmh25j._.js",
      "static/chunks/[next]_entry_page-loader_ts_0us8f40_t-gfo._.js",
      "static/chunks/1dte_react-dom_cjs_react-dom-client_development_02rz9zcargxd8.js",
      "static/chunks/1dte_react-dom_cjs_react-dom_development_00h-fwcj3w1ch.js",
      "static/chunks/1dte_react-dom_1cwiudm097nqd._.js",
      "static/chunks/1dte_0sbyeriiuulq8._.js",
      "static/chunks/[root-of-the-server]__118i5m1ij_l4j._.js",
      "static/chunks/seatlock_pages__error_0o72unl_gp5sp._.js",
      "static/chunks/turbopack-seatlock_pages__error_00hhzw85_wk1f._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/1dte_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_05y_df2kekv_6._.js",
    "static/chunks/1dte_next_dist_compiled_next-devtools_index_05vv_5h93-svg.js",
    "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom-client_development_0u904hy8uprcn.js",
    "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom_development_1bv9d36bubzdl.js",
    "static/chunks/1dte_next_dist_compiled_react-dom_0bhmtow4thkdc._.js",
    "static/chunks/1dte_next_dist_compiled_react-server-dom-turbopack_0-gv0078dot25._.js",
    "static/chunks/1dte_next_dist_compiled_05ref_8sdj16w._.js",
    "static/chunks/1dte_next_dist_client_1dpm_8066kx89._.js",
    "static/chunks/1dte_next_dist_0ai63qxgp9p5-._.js",
    "static/chunks/1dte_@swc_helpers_cjs_05qxzk67r-gng._.js",
    "static/chunks/seatlock_1anvha4rlo79g._.js",
    "static/chunks/turbopack-seatlock_1b0jn64de1z4f._.js"
  ],
  "rootMainFilesTree": {
    "/audit/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_05y_df2kekv_6._.js",
      "static/chunks/1dte_next_dist_compiled_next-devtools_index_05vv_5h93-svg.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom-client_development_0u904hy8uprcn.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom_development_1bv9d36bubzdl.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_0bhmtow4thkdc._.js",
      "static/chunks/1dte_next_dist_compiled_react-server-dom-turbopack_0-gv0078dot25._.js",
      "static/chunks/1dte_next_dist_compiled_05ref_8sdj16w._.js",
      "static/chunks/1dte_next_dist_client_1dpm_8066kx89._.js",
      "static/chunks/1dte_next_dist_0ai63qxgp9p5-._.js",
      "static/chunks/1dte_@swc_helpers_cjs_05qxzk67r-gng._.js",
      "static/chunks/seatlock_1anvha4rlo79g._.js",
      "static/chunks/turbopack-seatlock_1b0jn64de1z4f._.js",
      "static/chunks/seatlock_0oemg9w3rln01._.js"
    ],
    "/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_05y_df2kekv_6._.js",
      "static/chunks/1dte_next_dist_compiled_next-devtools_index_05vv_5h93-svg.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom-client_development_0u904hy8uprcn.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom_development_1bv9d36bubzdl.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_0bhmtow4thkdc._.js",
      "static/chunks/1dte_next_dist_compiled_react-server-dom-turbopack_0-gv0078dot25._.js",
      "static/chunks/1dte_next_dist_compiled_05ref_8sdj16w._.js",
      "static/chunks/1dte_next_dist_client_1dpm_8066kx89._.js",
      "static/chunks/1dte_next_dist_0ai63qxgp9p5-._.js",
      "static/chunks/1dte_@swc_helpers_cjs_05qxzk67r-gng._.js",
      "static/chunks/seatlock_1anvha4rlo79g._.js",
      "static/chunks/turbopack-seatlock_1b0jn64de1z4f._.js",
      "static/chunks/seatlock_219uq1sj0q91c._.js"
    ],
    "/shard-test/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_05y_df2kekv_6._.js",
      "static/chunks/1dte_next_dist_compiled_next-devtools_index_05vv_5h93-svg.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom-client_development_0u904hy8uprcn.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_cjs_react-dom_development_1bv9d36bubzdl.js",
      "static/chunks/1dte_next_dist_compiled_react-dom_0bhmtow4thkdc._.js",
      "static/chunks/1dte_next_dist_compiled_react-server-dom-turbopack_0-gv0078dot25._.js",
      "static/chunks/1dte_next_dist_compiled_05ref_8sdj16w._.js",
      "static/chunks/1dte_next_dist_client_1dpm_8066kx89._.js",
      "static/chunks/1dte_next_dist_0ai63qxgp9p5-._.js",
      "static/chunks/1dte_@swc_helpers_cjs_05qxzk67r-gng._.js",
      "static/chunks/seatlock_1anvha4rlo79g._.js",
      "static/chunks/turbopack-seatlock_1b0jn64de1z4f._.js",
      "static/chunks/seatlock_0_sc6bi5c3-6s._.js"
    ]
  },
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
