var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/1dte_1x14fbu0bwt0d._.js")
R.c("server/chunks/ssr/[externals]__1vp7etusa_gny._.js")
R.m("[project]/seatlock/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/seatlock/node_modules/next/document.js [ssr] (ecmascript)").exports
