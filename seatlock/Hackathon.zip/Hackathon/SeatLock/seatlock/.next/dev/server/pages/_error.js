var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/1dte_1gt_d9z1he6mw._.js")
R.c("server/chunks/ssr/[externals]__10y2j2aka8e1v._.js")
R.c("server/chunks/ssr/1dte_1x14fbu0bwt0d._.js")
R.c("server/chunks/ssr/[externals]__1vp7etusa_gny._.js")
R.c("server/chunks/ssr/1dte_next_1mvs2uuiqgyj3._.js")
R.m("[project]/seatlock/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/seatlock/node_modules/next/dist/pages/_error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/seatlock/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/seatlock/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/seatlock/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/seatlock/node_modules/next/dist/pages/_error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/seatlock/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/seatlock/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
