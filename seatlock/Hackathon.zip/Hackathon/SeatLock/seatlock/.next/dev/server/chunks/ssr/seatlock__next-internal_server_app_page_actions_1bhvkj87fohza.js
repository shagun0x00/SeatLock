module.exports = [
"[project]/seatlock/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=seatlock__next-internal_server_app_page_actions_1bhvkj87fohza.js.map