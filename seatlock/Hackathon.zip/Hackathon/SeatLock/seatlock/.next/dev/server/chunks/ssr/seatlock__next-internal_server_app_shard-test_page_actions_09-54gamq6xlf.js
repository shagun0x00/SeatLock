module.exports = [
"[project]/seatlock/.next-internal/server/app/shard-test/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=seatlock__next-internal_server_app_shard-test_page_actions_09-54gamq6xlf.js.map