module.exports = [
"[externals]/next/dist/server/app-render/module-loading/track-module-loading.external.js [external] (next/dist/server/app-render/module-loading/track-module-loading.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/module-loading/track-module-loading.external.js", () => require("next/dist/server/app-render/module-loading/track-module-loading.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/seatlock/src/app/favicon.ico (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.117ezoe8m31dk.ico" + (globalThis["NEXT_CLIENT_ASSET_SUFFIX"] || ''));}),
"[project]/seatlock/src/app/favicon.ico.mjs { IMAGE => \"[project]/seatlock/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/seatlock/src/app/favicon.ico (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 48,
    height: 48
};
}),
"[project]/seatlock/src/app/shard-test/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ShardTestPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seatlock/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$modules$2f$m3$2f$audit$2f$shardTest$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seatlock/src/modules/m3/audit/shardTest.ts [app-rsc] (ecmascript)");
;
;
function ShardTestPage() {
    const results = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$modules$2f$m3$2f$audit$2f$shardTest$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["findEventsForAllShards"])();
    const actorShard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$modules$2f$m3$2f$audit$2f$shardTest$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getActorShardResult"])();
    const shardCount = Object.keys(results).length;
    const passed = shardCount === 4;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-100 p-6 text-gray-900",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-4xl space-y-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    className: "rounded-xl bg-white p-6 shadow",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-3xl font-bold",
                            children: "Audit Shard Routing Test"
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 18,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-2 text-gray-600",
                            children: "Verify routing across four audit shards."
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 21,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                    lineNumber: 17,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "rounded-xl bg-white p-6 shadow",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-bold",
                            children: "Test Status"
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 28,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: `mt-3 font-bold ${passed ? "text-green-700" : "text-red-700"}`,
                            children: passed ? "PASS - All 4 shards found" : "FAIL - Shards missing"
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 30,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-2 text-gray-700",
                            children: [
                                "Shards found: ",
                                shardCount,
                                "/4"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 34,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                    lineNumber: 27,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "rounded-xl bg-white p-6 shadow",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "mb-4 text-xl font-bold",
                            children: "Event Routing"
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 41,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-3",
                            children: Object.entries(results).map(([shard, eventId])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-gray-200 p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium text-gray-900",
                                            children: eventId
                                        }, void 0, false, {
                                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                                            lineNumber: 49,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "rounded-lg bg-blue-100 px-3 py-2 font-mono font-semibold text-blue-800",
                                            children: shard
                                        }, void 0, false, {
                                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                                            lineNumber: 53,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, shard, true, {
                                    fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                                    lineNumber: 45,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 43,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                    lineNumber: 40,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "rounded-xl bg-white p-6 shadow",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-bold",
                            children: "Actor Routing"
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 63,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-3 text-gray-700",
                            children: "Actor ID: user-101"
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 65,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-2 font-mono font-bold text-blue-700",
                            children: [
                                "Shard: ",
                                actorShard
                            ]
                        }, void 0, true, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 69,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                    lineNumber: 62,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "rounded-xl bg-white p-6 shadow",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "mb-4 text-xl font-bold",
                            children: "Available Shards"
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 76,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
                            children: [
                                0,
                                1,
                                2,
                                3
                            ].map((number)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-lg border bg-gray-50 p-4 text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-600",
                                            children: [
                                                "Shard ",
                                                number
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                                            lineNumber: 84,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-1 font-mono font-bold text-gray-900",
                                            children: [
                                                "audit_logs_",
                                                number
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                                            lineNumber: 85,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, number, true, {
                                    fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                                    lineNumber: 80,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                            lineNumber: 78,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
                    lineNumber: 75,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
            lineNumber: 15,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/seatlock/src/app/shard-test/page.tsx",
        lineNumber: 14,
        columnNumber: 9
    }, this);
} // import {
 //   getShardTestResults,
 //   getActorShardResult,
 // } from "@/modules/m3/audit/shardTest";
 // export default function ShardTestPage() {
 //   const results = getShardTestResults();
 //   const actorShard = getActorShardResult();
 //   return (
 //     <main className="min-h-screen bg-gray-100 px-4 py-8 text-gray-900 sm:px-8">
 //       <div className="mx-auto max-w-4xl space-y-6">
 //         {/* Header */}
 //         <header className="rounded-2xl bg-white p-6 shadow-sm">
 //           <p className="text-sm font-semibold text-blue-700">
 //             SeatLock / M3 Operations
 //           </p>
 //           <h1 className="mt-2 text-3xl font-bold text-gray-900">
 //             Audit Shard Routing Test
 //           </h1>
 //           <p className="mt-2 text-gray-600">
 //             Verify event-based and actor-based audit routing across 4 shards.
 //           </p>
 //         </header>
 //         {/* Event Routing */}
 //         <section className="overflow-hidden rounded-2xl border border-gray-300 bg-white shadow-sm">
 //           <div className="border-b border-gray-200 p-5">
 //             <h2 className="text-xl font-bold text-gray-900">
 //               Event Routing
 //             </h2>
 //             <p className="mt-1 text-sm text-gray-600">
 //               Event IDs are mapped to audit shard tables.
 //             </p>
 //           </div>
 //           <div className="overflow-x-auto">
 //             <table className="w-full text-left">
 //               <thead className="bg-gray-100">
 //                 <tr>
 //                   <th className="px-5 py-4 text-sm font-semibold text-gray-800">
 //                     Event ID
 //                   </th>
 //                   <th className="px-5 py-4 text-sm font-semibold text-gray-800">
 //                     Shard Table
 //                   </th>
 //                 </tr>
 //               </thead>
 //               <tbody>
 //                 {results.map((item) => (
 //                   <tr
 //                     key={item.eventId}
 //                     className="border-t border-gray-200 hover:bg-gray-50"
 //                   >
 //                     <td className="px-5 py-4 font-medium text-gray-900">
 //                       {item.eventId}
 //                     </td>
 //                     <td className="px-5 py-4">
 //                       <span className="inline-flex rounded-lg bg-blue-100 px-3 py-1.5 font-mono text-sm font-semibold text-blue-800">
 //                         {item.shard}
 //                       </span>
 //                     </td>
 //                   </tr>
 //                 ))}
 //               </tbody>
 //             </table>
 //           </div>
 //         </section>
 //         {/* Actor Routing */}
 //         <section className="rounded-2xl border border-gray-300 bg-white p-6 shadow-sm">
 //           <h2 className="text-xl font-bold text-gray-900">
 //             Actor Routing
 //           </h2>
 //           <p className="mt-2 text-gray-600">
 //             Used when an audit action does not have an Event ID.
 //           </p>
 //           <div className="mt-5 grid gap-4 sm:grid-cols-2">
 //             <div className="rounded-xl bg-gray-100 p-4">
 //               <p className="text-sm font-medium text-gray-600">
 //                 Actor ID
 //               </p>
 //               <p className="mt-1 font-semibold text-gray-900">
 //                 user-101
 //               </p>
 //             </div>
 //             <div className="rounded-xl bg-blue-50 p-4">
 //               <p className="text-sm font-medium text-blue-700">
 //                 Assigned Shard
 //               </p>
 //               <p className="mt-1 font-mono text-lg font-bold text-blue-900">
 //                 {actorShard}
 //               </p>
 //             </div>
 //           </div>
 //         </section>
 //         {/* Shard Information */}
 //         <section className="rounded-2xl border border-gray-300 bg-white p-6 shadow-sm">
 //           <h2 className="text-xl font-bold text-gray-900">
 //             Shard Information
 //           </h2>
 //           <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
 //             {[0, 1, 2, 3].map((shard) => (
 //               <div
 //                 key={shard}
 //                 className="rounded-xl border border-gray-200 bg-gray-50 p-4 text-center"
 //               >
 //                 <p className="text-sm text-gray-600">Shard {shard}</p>
 //                 <p className="mt-1 font-mono font-bold text-gray-900">
 //                   audit_logs_{shard}
 //                 </p>
 //               </div>
 //             ))}
 //           </div>
 //         </section>
 //         <footer className="py-2 text-center text-sm text-gray-500">
 //           SeatLock Hackathon · M3 Audit & Operations
 //         </footer>
 //       </div>
 //     </main>
 //   );
 // }
}),
"[project]/seatlock/src/app/shard-test/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", (function(__turbopack_context__){

__turbopack_context__.n(__turbopack_context__.i("[project]/seatlock/src/app/shard-test/page.tsx [app-rsc] (ecmascript)"));
}),
"[project]/seatlock/src/modules/m3/audit/shardRouter.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAuditShard",
    ()=>getAuditShard,
    "getAuditShardTable",
    ()=>getAuditShardTable
]);
// har audit log ko 4 database tables mein se sahi table assign karna.
var __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/crypto [external] (crypto, cjs)");
;
/**
 * Generates a stable hash and maps it to one of 4 audit shards.
 */ function hashToShard(key) {
    const hash = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["createHash"])("sha256").update(key).digest();
    const shard = hash.readUInt32BE(0) % 4;
    return shard;
}
function getAuditShard(eventId, actorId) {
    const key = eventId?.trim() || actorId?.trim();
    if (!key) {
        throw new Error("eventId or actorId is required for audit sharding");
    }
    return hashToShard(key);
}
function getAuditShardTable(eventId, actorId) {
    const shard = getAuditShard(eventId, actorId);
    return `audit_logs_${shard}`;
}
}),
"[project]/seatlock/src/modules/m3/audit/shardTest.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "findEventsForAllShards",
    ()=>findEventsForAllShards,
    "getActorShardResult",
    ()=>getActorShardResult,
    "verifyAllShards",
    ()=>verifyAllShards
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$modules$2f$m3$2f$audit$2f$shardRouter$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seatlock/src/modules/m3/audit/shardRouter.ts [app-rsc] (ecmascript)");
;
function findEventsForAllShards() {
    const found = {};
    for(let i = 1; i <= 1000; i++){
        const eventId = `test-event-${i}`;
        const shard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$modules$2f$m3$2f$audit$2f$shardRouter$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAuditShardTable"])(eventId, undefined);
        if (!found[shard]) {
            found[shard] = eventId;
        }
        if (Object.keys(found).length === 4) {
            break;
        }
    }
    return found;
}
function verifyAllShards() {
    const results = findEventsForAllShards();
    return {
        results,
        passed: Object.keys(results).length === 4,
        totalShardsFound: Object.keys(results).length
    };
}
function getActorShardResult() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$seatlock$2f$src$2f$modules$2f$m3$2f$audit$2f$shardRouter$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAuditShardTable"])(undefined, "user-101");
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0g0zm2liaqt5d._.js.map